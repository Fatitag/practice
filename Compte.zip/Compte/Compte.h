#ifndef COMPTE_H
#define COMPTE_H


class Compte
{
    public:
        void Initialiser();
        void Consulter();
        void retirer(float);
        void depot(float);
        int GetNumCmp();

    private:
        int Num_compte;
        char Nom_cl[50];
        float solde;
};

#endif�//�COMPTE_H
