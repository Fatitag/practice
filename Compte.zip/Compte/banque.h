#ifndef BANQUE_
#define BANQUE_

#include "Compte.h"
class Banque
{
    public:
        void Initialiser_Banque();
        void Afficher_Banque();
        void add(Compte );
        void Supprimer(int);
        Compte getCompte(int);

    protected:

    private:
        Compte Agence[1000];
        int Nbre_Comptes;
};

#endif // BANQUE_
