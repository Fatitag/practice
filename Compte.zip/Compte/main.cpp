#include <iostream>
#include "compte.h"
#include "banque.h"
using namespace std;

int main()
{
Compte C1,C2;
C1.Initialiser();
C2.Initialiser();

    return 0;
}
