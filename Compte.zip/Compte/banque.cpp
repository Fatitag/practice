#include "banque.h"
#include <iostream>
using namespace std;
void Banque::Initialiser_Banque(){
Nbre_Comptes=0;
}
void Banque::Afficher_Banque(){
cout<<"Affichage de la banque: "<<endl;
for(int i=0;i<Nbre_Comptes;i++)
{
    Agence[i].Consulter();
}
}
void Banque::add(Compte x){
Agence[Nbre_Comptes]=x;
Nbre_Comptes++;
}void Banque::Supprimer(int x){
int i,j;
for(i=0;i<Nbre_Comptes;i++){
    if (Agence [i].getNumCompte () ==n) break;
}
for(j=i;j<Nbre_Comptes-1;j++){
    Agence [j]=Agence [j+1];

}
Nbre Comptes--:
}
Compte Banque::getCompte (int n){
    int i;
for(i=0;i<Nbre_Comptes;i++){
    if (Agence[i].getNumCompte()==n) return �Agence[i];
}

}

