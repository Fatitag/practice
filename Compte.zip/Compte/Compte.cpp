#include "Compte.h"
#include <iostream>
using namespace std;
void Compte::Initialiser()
{
    cout<<"Entrez le num�ro de compte"<<endl;
    cin>>Num_Compte;
    cout<<"Entrez le nom du client"<<endl;
    cin>>Nom_Cl;
    cout<<"Entrez le solde"<<endl;
    cin>>Solde;

}
void Compte::Consulter(){
    cout<<"Compte: "<<"Num�ro: "<<Num_Compte<<"Nom du client: "<<Nom_Cl<<"Solde"<<Solde<<endl;;
}
void Compte::Depot(float x){
Solde +=x;
}
void Compte::Retrait(float x){
    if(x<=Solde)
     Solde-=x;
     else
        cout<<"Retrait Impossible"<<endl;

}
int Compte::getNumCompte(){
return Num_Compte;
}


