#ifndef POINT_H
#define POINT_H
#include <iostream>
using namespace std;

class Point{
    private:float x,y;char* nom;
//public,private:modification d'axes
    public:
        Point();
        Point(float,const char*);
        Point(float,float,const char*);
        Point(const Point&);
        ~Point();
        Point & operator=(const Point&);
        Point & operator+(const Point&);
        Point & operator*(float);
        friend Point& operator*(float ,const Point&);
        void affiche();
};

#endif // POINT_H
