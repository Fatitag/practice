#include <iostream>
#include "Point.h"
using namespace std;

int main()
{
    Point A,B(1,4,"b"),c(1,"f"),D=c;
    cout<<"******************"<<endl;
    A=c;//une affectation pas constrictor recopie A=emplicite C=explicite
    cout<<"******************"<<endl;
    D=B+A;
    D.affiche();
    D=A*5;//A.operatoe*(5)
    D.affiche();
    // Err:A=5*B;
    return 0;
}
