#include <iostream>
#include "Point.h"
using namespace std;
#include <string.h>

Point::Point(){
     x=0;y=0;
     nom=new char[20];
     strcpy(nom,"ABCD");
     cout<<"constuctor par defaut"<<endl;
}

Point::Point(float h,const char* n){
     x=h;y=h;
     nom=new char[strlen(n)+1];
     strcpy(nom,n);
     cout<<"constuctor 2 para"<<endl;
}

Point::Point(float h,float e,const char* n){
     x=h;y=e;
     nom=new char[strlen(n)+1];
     strcpy(nom,n);
     cout<<"constuctor 3 para"<<endl;
}

Point::Point(const Point &p){
     this->x=x;this->y=y;
     this->nom=new char[strlen(p.nom)+1];
     strcpy(this->nom,p.nom);
     cout<<"constuctor recopie"<<endl;
}

Point & Point::operator=(const Point &p){
     this->x=p.x;this->y=p.y;
     delete[] this->nom;//diff entre operateur d'affectation et constructor recopie
     this->nom=new char[strlen(p.nom)+1];
     strcpy(this->nom,p.nom);
     cout<<"operateur d'affectation"<<endl;
     return *this;//et ca
}

Point & Point::operator+(const Point &p){
     static Point res;
     res.x=x+p.x;
     res.y=y+p.y;
     strcpy(res.nom,nom);
     strcat(res.nom,p.nom);
     cout<<"operator+ "<<endl;
     return res;
}

Point & Point::operator*(float h){
     static Point res;
     res.x=h*x;
     res.y=h*y;
     cout<<"methode * "<<endl;
     return res;
}

Point& operator*(float h,const &p){
    static Point res;
    res.x=h*p.x;
    res.y=h*p.y;
    cout<<"fonction amis "<<endl;
    return res;
}

void Point::affiche(){
    cout<<"("<<this->x<<","<<this->y<<")"<<endl;
}

Point::~Point(){
delete[] nom;
}
