var lat = 34.65903237542231;
var lon = -1.9145246897260653;
var tab = [];
function Display() {
    var meteo = document.getElementById('meteo');
    var scroll = document.getElementById('scroll');
    var table = document.getElementById('table');
    scroll.innerHTML = "";
    table.innerHTML = "";
    var degree = document.getElementById("temperature");
    degree.innerHTML = Math.floor(tab.current.temperature_2m) + "°";
    //hourly forecast
    var time = tab.current.time.substring(0, 14) + "00";
    var currentIndex = tab.hourly.time.indexOf(time);
    for (let i = currentIndex; i < currentIndex + 5; i++) {
        var hour = tab.hourly.time[i];
        var temp = tab.hourly.temperature_2m[i];
        var hourString = hour.substring(11, 13);
        if (hourString === "24") {
            hourString = "00";
        }
        var displayedHour = (parseInt(hourString) + 1) % 24; 
        scroll.innerHTML += `<div class="time">
                                <span>${displayedHour}:00</span>
                                <i class="fa-solid fa-sun"></i>
                                <span>${temp}°</span>
                                <i class="fa-solid fa-droplet">0%</i>
                            </div>`;
    }
    //daily forecast
    var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    for (let i = 0; i < 7; i++) {
        var date = new Date(tab.daily.time[i]);
        var dayIndex = date.getDay();
        var day = days[dayIndex];
        table.innerHTML += `<div class="day">
                                <span>${day}</span>
                                <i class="fa-solid fa-droplet">0%</i>
                                <i class="fa-solid fa-sun"></i>
                                <i class="fa-solid fa-moon"></i>
                                <span>${tab.daily.temperature_2m_max[i]}°</span>
                                <span>${tab.daily.temperature_2m_min[i]}°</span>
                            </div>`;
    }
    var sunrise = document.getElementById("heuresunrise");
    var sunset = document.getElementById("heuresunset");
    var heure_de_sunrise = tab.daily.sunrise[0];
    var heure_de_sunset = tab.daily.sunset[0];
    sunrise.innerHTML = heure_de_sunrise.substring(11, 16);
    sunset.innerHTML = heure_de_sunset.substring(11, 16);
}
function load(callback) {
    var xhr = new XMLHttpRequest();
    xhr.open(
        "GET",
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&hourly=temperature_2m&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset`
    );
    xhr.onload = function () {
        if (xhr.status === 200) {
            tab = JSON.parse(xhr.response);
            callback();
        }
    }
    xhr.send();
}
load(Display);
function Weather(city) {
    var apiKey = 'ba7d0cfc360007a3846a76554b81e945';
    var url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('City not found');
            }
            return response.json();
        })
        .then(data => {
            console.log('Weather data:', data);
    const humidity = data.main.humidity;
    const humidityElements = document.querySelectorAll('.scroll .fa-solid.fa-droplet, .table .fa-solid.fa-droplet');

    humidityElements.forEach(element => {
        element.innerText = humidity + '%';
    });
            var temperature = data.main.temp + '°C';
var feelsLike = 'Feels like ' + data.main.feels_like + '°C';
var icon= data.weather.icon;

var weatherDescription = data.weather[0].description;
const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const dayIndex = new Date(data.dt * 1000).getDay();
const day = days[dayIndex];
var timeString = day.substring(0, 3) + ', ' + new Date(data.dt * 1000).toLocaleTimeString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
var description = temperature + ', ' + weatherDescription + '<br>' + feelsLike + '<br>' + timeString;
document.getElementById('weatherDescription').innerHTML = description;
            // const weatherCondition = data.weather[0].main.toLowerCase();
            // let iconClass;
            // switch (weatherCondition) {
            //     case 'clear':
            //         iconClass = 'fas fa-sun';
            //         break;
            //     case 'clouds':
            //         iconClass = 'fas fa-cloud';
            //         break;
            //     case 'rain':
            //         iconClass = 'fas fa-cloud-showers-heavy';
            //         break;
            //     default:
            //         iconClass = 'fas fa-question-circle';
            //         break;
            // }
            // document.getElementById('meteo').querySelector('i').className = iconClass;
            // var hourlyIcons = document.querySelectorAll('.scroll .time i.fa-solid.fa-sun');
            // hourlyIcons.forEach(icon => {
            //     icon.className = iconClass;
            // });
            // var dailyIcons = document.querySelectorAll('.table .day i.fa-solid.fa-sun');
            // dailyIcons.forEach(icon => {
            //     icon.className = iconClass;
            // });
        })
        .catch(error => {
            console.error('Error fetching weather:', error);
            alert(error.message);
        });
        
}
Weather('oujda');
