var tab = [];
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function (position) {
                var lat = position.coords.latitude;
                var lon = position.coords.longitude;
                load(lat, lon, Display);
                Weather(lat, lon);
            },
            function (error) {
                // console.log("Error location: " + error.message);
            }
        );
    } 
}

function Display() {
    var meteo = document.getElementById('meteo');
    meteo.innerHTML = `<i class="fa-solid ${getIconClass(tab.current.weather_code)}"></i>`;
    var scroll = document.getElementById('scroll');
    var table = document.getElementById('table');
    scroll.innerHTML = "";
    table.innerHTML = "";
    //sunsetSunrise
    var sunrise = document.getElementById("sunriseTime");
    var sunset = document.getElementById("sunsetTime");
    var sunriseTime = tab.daily.sunrise[0];
    var sunsetTime = tab.daily.sunset[0];
    console.log(sunriseTime)
    console.log(sunsetTime)
    sunrise.innerHTML = sunriseTime.substring(11);
    sunset.innerHTML = sunsetTime.substring(11);
    //temperature
    var degree = document.getElementById("temperature");
    degree.innerHTML = Math.floor(tab.current.temperature_2m) + "°";
    //hourly 
    var currentIndex = tab.hourly.time.indexOf(tab.current.time.substring(0, 14) + "00");
    for (let i = currentIndex; i < currentIndex + 8; i++) {
        var hour = tab.hourly.time[i];
        var temp = tab.hourly.temperature_2m[i];
        var weatherCode = tab.hourly.weather_code[i];
        var hourS = ('0' + ((parseInt(hour.substring(11, 13)) + 1) % 24)).slice(-2);
        var iconClass = getIconClass(weatherCode); 
        scroll.innerHTML += `<div class="time">
            <span>${hourS}:00</span>
            <i class="fa-solid ${iconClass} white-icon"></i> 
            <span>${temp}°</span>
            <div class="ple">
                <i class="fa-solid fa-droplet"><span class="percentage">0%</span></i>
            </div>
        </div>`;
    }

    //daily
    var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var today = new Date().getDay();
    for (let i = 0; i < 7; i++) {
        var date = new Date(tab.daily.time[i]);
        var dayIndex = date.getDay();
        var day = days[dayIndex];
        if (i === 0) day = "Today";
        iconClass = getIconClass(tab.daily.weather_code[i]); 

        table.innerHTML += `<div class="day">
                                <span>${day}</span>
                                <i class="fa-solid fa-droplet"><span>0%</span></i>
                                <i class="fa-solid ${getIconClass(tab.daily.weather_code[i])}"></i>
                                <i class="fa-solid fa-moon"></i>
                                <span>${tab.daily.temperature_2m_max[i]}°</span>
                                <span>${tab.daily.temperature_2m_min[i]}°</span>
                            </div>`;
    }
    function getIconClass(weatherCode) {
        var icons = {
            0: "fa-sun",
            1: "fa-cloud-sun",  
            2: "fa-cloud-sun",  
            3: "fa-cloud",  
            51: "fa-cloud-drizzle",  
            55: "fa-cloud-drizzle",  
            56: "fa-snowflake",  
            57: "fa-snowflake",  
            61: "fa-cloud-rain", 
            63: "fa-cloud-rain",  
            65: "fa-cloud-rain", 
        };
        return icons[weatherCode] || "fa-sun";
    }
}

function load(lat, lon, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open(
        "GET",`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&hourly=temperature_2m,weather_code,precipitation&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset`);
    xhr.onload = function () {
        if (xhr.status === 200) {
            tab = JSON.parse(xhr.response);
            callback();
        }
    };
    xhr.send();
}

function Weather(lat, lon) {
    var apiKey = 'ba7d0cfc360007a3846a76554b81e945';
    var url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
    fetch(url)
        .then(response => {
            if (!response.ok) {
                // throw new Error('Error ');
            }
            return response.json();
        })
        .then(data => {
                                                            // console.log('Weather data:', data);
            var temperature = data.main.temp + '°C';
            var feelsLike = 'Feels like ' + data.main.feels_like + '°C';
            var humidity = 'Humidity: ' + data.main.humidity + '%';
            var weatherDescription = data.weather[0].description;
            var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            var dayIndex = new Date(data.dt * 1000).getDay();
            var day = days[dayIndex];
            var timeS = day.substring(0, 3) + ', ' + new Date(data.dt * 1000).toLocaleTimeString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
            var description = temperature + ', ' + weatherDescription + '<br>' + feelsLike + '<br>' + humidity + '<br>' + timeS;
            document.getElementById('weatherDescription').innerHTML = description;
        })
        .catch(error => {
            console.error('Error fetching weather:', error);
            alert(error.message);
        });
}

getLocation();
