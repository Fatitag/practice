#include <iostream>
using namespace std;

int main()
{
    Personne a,b("abcd","efg",25);
    a.afficher();
    b.afficher();
        return 0;
}
