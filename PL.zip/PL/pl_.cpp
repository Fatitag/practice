#include "pl_.h"
#include <iostream>
using namespace std;

PL_::PL_(int n)
{
    dim=n;
    adr=new int[dim];
    taille=0;
    //ctor
}

PL_::PL_(const PL_ &obj){
    int i;
    dim=obj.dim;
    taille=obj.taille;
    adr=new int[dim];
    for(i=0;i<obj.taille;i++){
        adr[i]=obj.adr[i];
    }
    cout<<"construction par recopie"<<endl;
}

PL_::~PL_(){
    delete [] adr;
}

PL_& PL_::operator=(const PL_ &obj){
    int i;
    dim=obj.dim;
    taille=obj.taille;
    delete [] adr;
    adr=new int[dim];
    for(i=0;i<obj.taille;i++){
        adr[i]=obj.adr[i];
    }
    cout<<"surcharge de = "<<endl;
    return *this;
}

bool PL_::operator==(const PL_ &p)const{
    if(taille==p.taille){
        for(int i=0;i<taille;i++){ if(adr[i]!=p.adr[i]) return false;}
        return true;
    }
    else return false;
}

int PL_::operator[](int n)const{
    return adr[n];
}
void PL_::operator<(int n){//empiler n dans la pile
    adr[taille]=n;
    taille++;
}
void PL_::operator--(){//depiler la pile, operateur unaire
    taille--;
}
PL_ &PL_::operator+(const PL_ &q)const{
    static PL_ r(q.dim);
    r.taille=q.taille;
    for(int i=0;i<taille;i++){ r.adr[i]=q.adr[i]+adr[i]; }
    return r;
}
bool PL_::pleinne() const{
        if(taille==dim) return true;
        else return false;
}

bool PL_::vide() const{
        if(taille==0) return true;
        else return false;
}

void PL_::empile(int p){
        if(pleinne()==false){
            adr[taille]=p;
            taille++;
        }
        else cout<<"impossible d'empiler la pille est pleinne"<<endl;
}

void PL_::depile(){
        if(vide()==false){
            taille--;
        }
        else cout<<"impossible depiler la pile est vide"<<endl;
}
/*
istream& operator>>(istream & istr ,PL_& p){
    cout<<"Entrez le nom"<<endl;
    istr>>p.nom;
    cout<<"Entrez x et y"<<endl;
    istr>>p.x>>p.y;
    return istr;
}

ostream& operator<<(ostream & ostr ,PL_& p){
    ostr<<p.nom<<"("<<p.x<<","<<p.y<<")"<<endl;
    return ostr;
}
*/
void PL_::affichep() const{
        int i;
        if(vide()==false){
            for(i=0;i<taille;i++) cout<<" "<<adr[i]<<" ";
            cout<<endl;
        }
        else cout<<"pile vide";
}

int PL_::donnetaille() const{
    return taille;
}
