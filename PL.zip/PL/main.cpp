#include <iostream>
#include "pl_.h"
using namespace std;

int main()
{
    PL_ p(5);
    p.depile();
    p.empile(1);
    p.empile(2);
    p.affichep();
    cout << "la taille est " <<p.donnetaille()<< endl;
    p.depile();
    p.affichep();
    return 0;
}
