#ifndef PL__H
#define PL__H


class PL_
{
    public:
        PL_(int =10);
        PL_(const PL_&);
        ~PL_();
        PL_& operator=(const PL_&);
        int operator[](int) const;
        bool pleinne() const;
        bool vide() const;
        bool operator==(const PL_&)const;
        void operator<(int);//empiler un entier dans la pile
        void operator--();//depiler la pile
        void affichep() const;
        PL_ &operator+(const PL_&)const;//une methode pour faire
        PL_ &operator+(int)const;
        friend PL_ &operator+(int, PL_&);
        void empile(int);
        void depile();
        int donnetaille() const;
       // friend istream& operator>>(istream & ,PL_&);
       // friend ostream& operator<<(ostream & ,PL_&);

    protected:

    private:
        int*adr,taille,dim;
};

#endif // PL__H
