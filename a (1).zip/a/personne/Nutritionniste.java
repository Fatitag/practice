package personne;

public class Nutritionniste extends Entraineur {
   
    public Nutritionniste(int id, String nom, String prenom, int age ,String specialite) {
        super(id, nom, prenom, age,specialite); 
    }
}
