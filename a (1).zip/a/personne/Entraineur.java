package personne;

public class Entraineur extends Personne {
    private String specialite;

  
    public Entraineur(int id, String nom, String prenom, int age, String specialite) {
        super(id, nom, prenom, age); 
        this.specialite = specialite;
    }

   
    public String getSpecialite() {
        return specialite;
    }

    
    public void setSpecialite(String specialite) {
        this.specialite = specialite;
    }
}
