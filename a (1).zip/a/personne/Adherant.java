package personne;

public class Adherant extends Personne {
   
    public Adherant(int id, String nom, String prenom, int age) {
        super(id, nom, prenom, age);
    }
}
