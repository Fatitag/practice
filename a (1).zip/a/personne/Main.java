package personne;

public class Main {
    public static void main(String[] args) {
        // Création d'une instance de Personne
        Personne personne = new Personne(1, "asmae", "bousfiha", 22);
        
        // Affichage des détails de la personne
        System.out.println("Détails de la personne :");
        System.out.println("ID: " + personne.getId());
        System.out.println("Nom: " + personne.getNom());
        System.out.println("Prénom: " + personne.getPrenom());
        System.out.println("Age: " + personne.getAge());
        
        // Modification de l'âge de la personne
        personne.setAge(30);
        
        // Affichage des détails mis à jour de la personne
        System.out.println("\nDétails de la personne après modification de l'âge :");
        System.out.println("ID: " + personne.getId());
        System.out.println("Nom: " + personne.getNom());
        System.out.println("Prénom: " + personne.getPrenom());
        System.out.println("Age: " + personne.getAge());
    }
}
